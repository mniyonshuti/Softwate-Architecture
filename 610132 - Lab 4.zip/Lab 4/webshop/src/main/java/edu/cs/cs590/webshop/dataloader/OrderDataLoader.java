package edu.cs.cs590.webshop.dataloader;

import org.springframework.stereotype.Component;

@Component
public class OrderDataLoader {

}
