package edu.cs.cs590.webshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebShopApplicationTests {

    @Test
    void contextLoads() {
    }

}
