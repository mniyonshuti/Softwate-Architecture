package edu.cs.cs590.webshop.webshopclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebShopClientApplicationTests {

    @Test
    void contextLoads() {
    }

}
