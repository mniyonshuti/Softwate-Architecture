package edu.cs.cs590.webshop.controller;

import edu.cs.cs590.webshop.model.ShoppingCart;
import edu.cs.cs590.webshop.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/order")
public class OrderController {

    @Autowired
    OrderService orderService;

    @PostMapping
    public void createOrder(@RequestBody ShoppingCart shoppingCart){
        orderService.createOrder(shoppingCart);
    }

    @GetMapping("/{orderId}")
    public ResponseEntity<?> getOrder(@PathVariable("orderId") String orderId) {
        return new ResponseEntity<>(orderService.getOrder(orderId), HttpStatus.OK);
    }
}
